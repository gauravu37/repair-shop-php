import"./chunk-Q7L6LLAK.js";var o=[{path:"",loadComponent:()=>import("./chunk-BU2IIXAX.js").then(t=>t.WidgetsComponent),data:{title:"Widgets"}}];export{o as routes};
