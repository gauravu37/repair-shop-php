import"./chunk-Q7L6LLAK.js";var t=[{path:"",loadComponent:()=>import("./chunk-7HV7T644.js").then(o=>o.DashboardComponent),data:{title:$localize`Dashboard`}}];export{t as routes};
