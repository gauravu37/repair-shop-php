var t={production:!0,apiUrl:"https://crm.prontoinfosys.net/api"};export{t as a};
